package SistemaAcademico;

public class Disciplina {

}
