package SistemaAcademico;

public class Frequencia {

}
