package SistemaAcademico;

public class Disciplina_Ofertada {

}
