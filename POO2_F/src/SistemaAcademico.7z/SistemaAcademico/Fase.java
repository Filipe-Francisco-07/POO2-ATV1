package SistemaAcademico;

public class Fase {

}
