package SistemaAcademico;

public class Professor {

}
