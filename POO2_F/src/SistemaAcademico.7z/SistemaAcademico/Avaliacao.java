package SistemaAcademico;

public class Avaliacao {

}
