package SistemaAcademico;

public class Aluno {

}
